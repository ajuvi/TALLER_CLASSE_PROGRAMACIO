﻿namespace ORDENAR_SELECCIO_DIRECTA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }

        static void SeleccioDirecta(int[] nums)
        {

        }

    }
}
